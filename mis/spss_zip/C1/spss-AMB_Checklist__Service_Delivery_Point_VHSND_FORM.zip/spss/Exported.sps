*Before running the syntax, please replace XXX with the correct path where the .dat file is located.

DATA LIST FILE='XXX\Exported.dat' RECORDS=1
/
UNIQUE_ID    1-15   (A)
STARTDATETIME    16-36   (A)
ENDDATETIME    37-57   (A)
DEVICE_ID    58-78   (A)
GPS    79-129   (A)
USERNAME    130-170   (A)
SURVEY_STATUS     171-191   (A)
TERMINATION_REASON    192-242   (A)
Q2    243-283   (A)
Q3    284-342   (A)
Q4    343-401   (A)
Q5    402-460   (A)
Q6    461-519   (A)
Q7    520-578   (A)
Q8    579-637   (A)
Q9    638-696   (A)
Q10    697-698   
Q11    699-799   (A)
Q12    800-811   
Q13    812-870   (A)
Q14    871-929   (A)
Q15    930-988   (A)
Q16    989-1001   
Q18    1002-1003   
Q20    1004-1017   
Q22    1018-1032   
Q23    1033-1048   
Q24    1049-1065   
Q25    1066-1083   
Q26    1084-1102   
Q27    1103-1122   
Q29    1123-1124   
Q30    1125-1183   (A)
Q32    1184-1185   
Q33    1186-1187   
Q34    1188-1189   
Q35    1190-1196   (A)
Q38    1197-1211   
Q39    1212-1224   
Q40    1225-1240   
Q41    1241-1257   
Q42    1258-1276   
Q43    1277-1296   
Q44    1297-1301   (A)
Q46    1302-1313   
Q47    1314-1328   
Q48    1329-1341   
Q49    1342-1355   
Q50    1356-1357   
Q52    1358-1359   
Q53    1360-1364   (A)
Q54    1365-1465   (A)
Q55    1466-1467   
Q56    1468-1469   
Q58    1470-1471   
Q59    1472-1530   (A)
Q61    1531-1532   
Q62    1533-1534   
Q64    1535-1536   
Q65    1537-1543   (A)
Q66    1544-1545   
Q67    1546-1552   (A)
Q69    1553-1554   
Q70    1555-1561   (A)
Q71    1562-1563   
Q72    1564-1570   (A)
Q73    1571-1572   
Q75    1573-1574   
Q76    1575-1576   
Q77    1577-1635   (A)
Q80    1636-1637   
Q81    1638-1639   
Q82    1640-1641   
Q84    1642-1643   
Q85    1644-1645   
Q86    1646-1647   
Q88    1648-1649   
Q89    1650-1651   
Q90    1652-1653   
Q92    1654-1712   (A)
Q93    1713-1771   (A)
Q94    1772-1830   (A)
Q95    1831-1889   (A)
Q96    1890-1948   (A)
Q97    1949-2007   (A).

VARIABLE LABELS Q2       "Date"
 /Q3       "State"
 /Q4       "District"
 /Q5       "Block"
 /Q6       "Name of CHCPHC"
 /Q7       "Name of Sub-center"
 /Q8       "Name of VHND siteAWC"
 /Q9       "Name of FLW"
 /Q10       "Designation"
 /Q11       "If others please specify"
 /Q12       "Mobile number"
 /Q13       "Name of SupervisorMonitor"
 /Q14       "Organization"
 /Q15       "Designation"
 /Q16       "Mobile No."
 /Q18       "1.1 Have you received any training on AMB in last three years"
 /Q20       "2.1 Total population catered count"
 /Q22       "2.2.1 Women in Reproductive Age count"
 /Q23       "2.2.2 Pregnant women count"
 /Q24       "2.2.3 Lactating women count"
 /Q25       "2.2.4 Children 6-59 months"
 /Q26       "2.2.5 Children 5-9 years out of school"
 /Q27       "2.2.6 Adolescents 10-19 years OOS"
 /Q29       "3.1 Which method is used to testscreen for anemia"
 /Q30       "If others please specify"
 /Q32       "3.2.1 Digital hemoglobinometers"
 /Q33       "Please select reason"
 /Q34       "3.2.2 Consumables"
 /Q35       "Please select reasons"
 /Q38       "4.1.1 Women in Reproductive Age count"
 /Q39       "4.1.2 Pregnant women count"
 /Q40       "4.1.3 Lactating women count"
 /Q41       "4.1.4 Children 6-59 months"
 /Q42       "4.1.5 Out of School Children 5-9 years"
 /Q43       "4.1.6 Out of School Adolescents Girls 10-19 years"
 /Q44       "4.2 Which of these beneficiaries do you provide Albendazole"
 /Q46       "4.3.1 Currently registered count"
 /Q47       "4.3.2 Screened anemic count"
 /Q48       "4.3.3 On treatment count"
 /Q49       "4.3.4 Severely anemic referred count"
 /Q50       "4.4 Does ANM has line listing of severe anemic PW observe"
 /Q52       "5.1 Whether any IEC material is displayed at the VHNDAWC"
 /Q53       "5.2 IEC methods used"
 /Q54       "If others please specify"
 /Q55       "5.3 Did the FLW give advice on key messages to beneficiary Observe an ANC session IFA supplementation deworming diet"
 /Q56       "5.4 Was any T3 camp organized in last three months in your catchment area"
 /Q58       "6.1 From where do you receivecollect the IFA and Albendazole"
 /Q59       "If others please specify"
 /Q61       "6.2.1 IFA"
 /Q62       "6.2.2 Albendazole"
 /Q64       "6.3.1 In last 3 months"
 /Q65       "If yes select type"
 /Q66       "6.3.2 In last 6 months"
 /Q67       "If yes select type"
 /Q69       "6.4.1 Next 3 months"
 /Q70       "If yes select type"
 /Q71       "6.4.2 Next 6 months"
 /Q72       "If yes select type"
 /Q73       "6.5 Is the available IFA within expiry date Observe"
 /Q75       "7.1 Have you received the new HMIS formats and training been given"
 /Q76       "7.2 Have you submitted the AMB report at your health facility every month in the last quarter"
 /Q77       "If no please state the reason"
 /Q80       "8.1.1 ANM"
 /Q81       "8.1.2 ASHA"
 /Q82       "8.1.3 AWW"
 /Q84       "8.2.1 ANM"
 /Q85       "8.2.2 ASHA"
 /Q86       "8.2.3 AWW"
 /Q88       "8.3.1 ANM"
 /Q89       "8.3.2 ASHA"
 /Q90       "8.3.3 AWW"
 /Q92       "8.4.1 Women in Reproductive Age"
 /Q93       "8.4.2 Pregnant women"
 /Q94       "8.4.3 Lactating women"
 /Q95       "8.4.4 Children 6-59 months"
 /Q96       "8.4.5 Children 5-9 years"
 /Q97       "8.4.6 Adolescents 10-19 years".

VALUE LABELS
 /Q10
     1 "ANM"
     2 "ASHA"
     3 "AWW"
     4 "Others"
 /Q18
     1 "Yes"
     2 "No"
 /Q29
     1 "Digital Hemoglobinometer"
     2 "Color coded card"
     3 "Sahlis method"
     4 "Others"
 /Q32
     1 "Yes"
     2 "No"
 /Q33
     1 "Digital hemoglobinometer not given"
     2 "Digital hemoglobinometer non-functional"
 /Q34
     1 "Yes"
     2 "No"
 /Q50
     1 "Yes"
     2 "No"
 /Q52
     1 "Yes"
     2 "No"
 /Q55
     1 "Yes"
     2 "No"
     3 "NA"
 /Q56
     1 "Yes"
     2 "No"
     3 "NA"
 /Q58
     1 "PHC"
     2 "CHC"
     3 "District Hospital"
     4 "Block Store"
     5 "District Store"
     6 "Others"
 /Q61
     1 "Monthly"
     2 "Quarterly"
     3 "Biannually"
     4 "Annually"
     5 "Half Annually"
     6 "Not Fixed"
 /Q62
     1 "Monthly"
     2 "Quarterly"
     3 "Biannually"
     4 "Annually"
     5 "Half Annually"
     6 "Not Fixed"
 /Q64
     1 "Yes"
     2 "No"
 /Q66
     1 "Yes"
     2 "No"
 /Q69
     1 "Yes"
     2 "No"
 /Q71
     1 "Yes"
     2 "No"
 /Q73
     1 "Yes"
     2 "No"
     3 "NA"
 /Q75
     1 "Both Yes"
     2 "Received - Yes Trained - No"
     3 "Received - No Trained - Yes"
     4 "Both No"
 /Q76
     1 "Yes"
     2 "No"
 /Q80
     1 "Yes"
     2 "No"
 /Q81
     1 "Yes"
     2 "No"
 /Q82
     1 "Yes"
     2 "No"
 /Q84
     1 "Yes"
     2 "No"
 /Q85
     1 "Yes"
     2 "No"
 /Q86
     1 "Yes"
     2 "No"
 /Q88
     1 "Yes"
     2 "No"
 /Q89
     1 "Yes"
     2 "No"
 /Q90
     1 "Yes"
     2 "No".

EXECUTE.
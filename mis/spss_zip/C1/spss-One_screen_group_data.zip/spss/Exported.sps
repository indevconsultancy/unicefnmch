*Before running the syntax, please replace XXX with the correct path where the .dat file is located.

DATA LIST FILE='XXX\Exported.dat' RECORDS=1
/
UNIQUE_ID    1-15   (A)
STARTDATETIME    16-36   (A)
ENDDATETIME    37-57   (A)
DEVICE_ID    58-78   (A)
GPS    79-129   (A)
USERNAME    130-170   (A)
SURVEY_STATUS     171-191   (A)
TERMINATION_REASON    192-242   (A)
TODAY    243-283   (A)
Q1    284-285   
Q2    286-326   (A)
Q3    327-328   
Q4    329-369   (A)
Q5    370-410   (A)
Q6    411-412   
Q7    413-415   
Q8    416-456   (A)
Q9    457-497   (A)
Q10    498-508   
Q11    509-511   
Q12    512-522   (A).

VARIABLE LABELS TODAY       "today"
 /Q1       "Monitor Name"
 /Q2       "Other Monitor Name"
 /Q3       "Select Monitor Type"
 /Q4       "Other Monitor Designation  organization"
 /Q5       "Date of Monitoring"
 /Q6       "district"
 /Q7       "block"
 /Q8       "otherblock"
 /Q9       "village"
 /Q10       "Name"
 /Q11       "Age"
 /Q12       "Mobile number".

VALUE LABELS
 /Q1
     1 "Suresh Tiwari"
     2 "Ravi Prakash Srivastava"
     3 "Anurag Singh"
     4 "Praveen Dubey"
     5 "Other"
 /Q3
     1 "APC"
     2 "SPC"
     3 "Other"
 /Q6
     1 "Shravasti"
     2 "Gorakhpur"
 /Q7
     1 "Kaudiram"
     2 "JANGALKODIA"
 /Q10
     1 "Shravasti"
     2 "Gorakhpur"
 /Q11
     1 "Kaudiram"
     2 "JANGALKODIA".

EXECUTE.
import delimited using "data.csv",delimiter(comma) varnames(1) case(preserve) asdouble encoding(UTF-8) clear

label variable uniqueid   "Unique Id"
label variable startDateTime   "Start DateTime"
label variable endDateTime   "End DateTime"
label variable device_id   "Device Id"
label variable GPS   "GPS"
label variable UserName   "UserName"
label variable SurveyStatus   "SurveyStatus"
label variable TerminationReason   "TerminationReason"
label variable q2   "Date"
label variable q3   "State"
label variable q4   "District"
label variable q5   "Block"
label variable q6   "Name of CHC/PHC"
label variable q7   "Name of Sub-center"
label variable q8   "Name of VHND site/AWC"
label variable q9   "Name of FLW"
label variable q10   "Designation"
label variable q11   "If others, please specify"
label variable q12   "Mobile number"
label variable q13   "Name of Supervisor/Monitor"
label variable q14   "Organization"
label variable q15   "Designation"
label variable q16   "Mobile No."
label variable q18   "1.1 Have you received any training on AMB in last three years?"
label variable q20   "2.1 Total population catered (count)"
label variable q22   "2.2.1 Women in Reproductive Age (count)"
label variable q23   "2.2.2 Pregnant women (count)"
label variable q24   "2.2.3 Lactating women (count)"
label variable q25   "2.2.4 Children (6-59 months)"
label variable q26   "2.2.5 Children (5-9 years) out of school"
label variable q27   "2.2.6 Adolescents (10-19 years) OOS"
label variable q29   "3.1 Which method is used to test/screen for anemia?"
label variable q30   "If others, please specify"
label variable q32   "3.2.1 Digital hemoglobinometers"
label variable q33   "Please select reason"
label variable q34   "3.2.2 Consumables"
label variable q35   "Please select reason(s)"
label variable q38   "4.1.1 Women in Reproductive Age (count)"
label variable q39   "4.1.2 Pregnant women (count)"
label variable q40   "4.1.3 Lactating women (count)"
label variable q41   "4.1.4 Children (6-59 months)"
label variable q42   "4.1.5 Out of School Children (5-9 years)"
label variable q43   "4.1.6 Out of School Adolescents Girls (10-19 years)"
label variable q44   "4.2 Which of these beneficiaries do you provide Albendazole?"
label variable q46   "4.3.1 Currently registered (count)"
label variable q47   "4.3.2 Screened anemic (count)"
label variable q48   "4.3.3 On treatment (count)"
label variable q49   "4.3.4 Severely anemic referred (count)"
label variable q50   "4.4 Does ANM has line listing of severe anemic PW? (observe)"
label variable q52   "5.1 Whether any IEC material is displayed at the VHND/AWC?"
label variable q53   "5.2 IEC methods used?"
label variable q54   "If others, please specify"
label variable q55   "5.3 Did the FLW give advice on key messages to beneficiary? Observe an ANC session (IFA supplementation, deworming, diet)"
label variable q56   "5.4 Was any T3 camp organized in last three months in your catchment area?"
label variable q58   "6.1 From where do you receive/collect the IFA and Albendazole?"
label variable q59   "If others, please specify"
label variable q61   "6.2.1 IFA"
label variable q62   "6.2.2 Albendazole"
label variable q64   "6.3.1 In last 3 months"
label variable q65   "If yes, select type"
label variable q66   "6.3.2 In last 6 months"
label variable q67   "If yes, select type"
label variable q69   "6.4.1 Next 3 months"
label variable q70   "If yes, select type"
label variable q71   "6.4.2 Next 6 months"
label variable q72   "If yes, select type"
label variable q73   "6.5 Is the available IFA within expiry date? (Observe)"
label variable q75   "7.1 Have you received the new HMIS formats and training been given?"
label variable q76   "7.2 Have you submitted the AMB report at your health facility, every month in the last quarter?"
label variable q77   "If no, please state the reason"
label variable q80   "8.1.1 ANM"
label variable q81   "8.1.2 ASHA"
label variable q82   "8.1.3 AWW"
label variable q84   "8.2.1 ANM"
label variable q85   "8.2.2 ASHA"
label variable q86   "8.2.3 AWW"
label variable q88   "8.3.1 ANM"
label variable q89   "8.3.2 ASHA"
label variable q90   "8.3.3 AWW"
label variable q92   "8.4.1 Women in Reproductive Age"
label variable q93   "8.4.2 Pregnant women"
label variable q94   "8.4.3 Lactating women"
label variable q95   "8.4.4 Children (6-59 months)"
label variable q96   "8.4.5 Children (5-9 years)"
label variable q97   "8.4.6 Adolescents (10-19 years)"

#delimit ;
label define Q10
     1 "ANM"
     2 "ASHA"
     3 "AWW"
     4 "Others"
;
label define Q18
     1 "Yes"
     2 "No"
;
label define Q29
     1 "Digital Hemoglobinometer"
     2 "Color coded card"
     3 "Sahlis method"
     4 "Others"
;
label define Q32
     1 "Yes"
     2 "No"
;
label define Q33
     1 "Digital hemoglobinometer not given"
     2 "Digital hemoglobinometer non-functional"
;
label define Q34
     1 "Yes"
     2 "No"
;
label define Q50
     1 "Yes"
     2 "No"
;
label define Q52
     1 "Yes"
     2 "No"
;
label define Q55
     1 "Yes"
     2 "No"
     3 "NA"
;
label define Q56
     1 "Yes"
     2 "No"
     3 "NA"
;
label define Q58
     1 "PHC"
     2 "CHC"
     3 "District Hospital"
     4 "Block Store"
     5 "District Store"
     6 "Others"
;
label define Q61
     1 "Monthly"
     2 "Quarterly"
     3 "Biannually"
     4 "Annually"
     5 "Half Annually"
     6 "Not Fixed"
;
label define Q62
     1 "Monthly"
     2 "Quarterly"
     3 "Biannually"
     4 "Annually"
     5 "Half Annually"
     6 "Not Fixed"
;
label define Q64
     1 "Yes"
     2 "No"
;
label define Q66
     1 "Yes"
     2 "No"
;
label define Q69
     1 "Yes"
     2 "No"
;
label define Q71
     1 "Yes"
     2 "No"
;
label define Q73
     1 "Yes"
     2 "No"
     3 "NA"
;
label define Q75
     1 "Both Yes"
     2 "Received - Yes, Trained - No"
     3 "Received - No, Trained - Yes"
     4 "Both No"
;
label define Q76
     1 "Yes"
     2 "No"
;
label define Q80
     1 "Yes"
     2 "No"
;
label define Q81
     1 "Yes"
     2 "No"
;
label define Q82
     1 "Yes"
     2 "No"
;
label define Q84
     1 "Yes"
     2 "No"
;
label define Q85
     1 "Yes"
     2 "No"
;
label define Q86
     1 "Yes"
     2 "No"
;
label define Q88
     1 "Yes"
     2 "No"
;
label define Q89
     1 "Yes"
     2 "No"
;
label define Q90
     1 "Yes"
     2 "No"
;

#delimit cr
label values q10     Q10
label values q18     Q18
label values q29     Q29
label values q32     Q32
label values q33     Q33
label values q34     Q34
label values q50     Q50
label values q52     Q52
label values q55     Q55
label values q56     Q56
label values q58     Q58
label values q61     Q61
label values q62     Q62
label values q64     Q64
label values q66     Q66
label values q69     Q69
label values q71     Q71
label values q73     Q73
label values q75     Q75
label values q76     Q76
label values q80     Q80
label values q81     Q81
label values q82     Q82
label values q84     Q84
label values q85     Q85
label values q86     Q86
label values q88     Q88
label values q89     Q89
label values q90     Q90

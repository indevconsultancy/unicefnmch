import delimited using "data.csv",delimiter(comma) varnames(1) case(preserve) asdouble encoding(UTF-8) clear

label variable uniqueid   "Unique Id"
label variable startDateTime   "Start DateTime"
label variable endDateTime   "End DateTime"
label variable device_id   "Device Id"
label variable GPS   "GPS"
label variable UserName   "UserName"
label variable SurveyStatus   "SurveyStatus"
label variable TerminationReason   "TerminationReason"
label variable today   "Today"
label variable mon_name   "Monitor Name"
label variable type_mon   "Select Monitor Type"
label variable oth_mon   "Other Monitor Organization"
label variable dom   "Date of Monitoring"
label variable jv   "Joint Visit"
label variable jv_name   "Name of Accompanying Person"
label variable jv_desigh   "Designation (Dept.) of Accompanying Person"
label variable district   "District"
label variable block   "Block Name"
label variable other_block   "Other Block Name"
label variable village   "Village Name"
label variable awc_name   "AWC Name"
label variable code_awc   "Code of AWC (11 digits)"
label variable aww_name   "Name of AWW"
label variable reg_05   "Number of 0-5 children registered in AWW Poshan Tracker"
label variable mes_05   "Number of 0-5 children measured by AWW last month"
label variable no_sam   "SAM"
label variable no_mam   "MAM"
label variable func_child_wm   "Child weighing machine"
label variable Func_adult_wm   "Mother-child weighing machine (Adult)"
label variable func_infanto   "Infantometer"
label variable func_stadio   "Stadiometer"
label variable sam_handout   "SAM Management Handout"
label variable CMAM_manual   "SAM Management Protocol (CMAM) displayed"
label variable thr_dis_month   "In which Month last THR distributed"
label variable hcm_prepared   "Hot cooked Meal distributed/ being cooked on the day of visit"
label variable smart_m_pt   "Does AWW have smart Mobile phone with Poshan Tracker installed"
label variable sam_due_list   "Does AWW has any list/Due-list of SAM cases?"
label variable coun_mat   "Does AWW has any counselling material (Job Aid)?"
label variable coun_mat_oth   "Specify other counselling material (Job Aid) AWW have?"
label variable aww_aware_mal   "What is the most severe form of malnutrition called as?"
label variable aww_trg_sam   "Have you received any training on management of children with SAM?"
label variable aww_aware_sambhav   "Do you know the name of annual campaign run by ICDS department for management of SAM cases?"
label variable aww_screen_sam   "What is essential to assess SAM/MAM in children at the AWC?"
label variable aww_aware_sam_identify   "After measuring weight & height what tool do you (AWW) use to know the SAM/MAM category?"
label variable aww_aware_bl_pitting   "Can you demonstrate how to check for bilateral pitting oedema?"
label variable sam_mgmt_steps   "According to you, what are the steps for management of child with SAM?"
label variable sam_first_ref   "Where will you mobilize the child if identified as SAM for the first time?"
label variable sam_mt   "What medical treatment shall a SAM case will receive if he/she has no illness and with good appetite?"
label variable sam_med   "Can you name the essential medicines/ nutritional supplements given to SAM case treated at the community level"
label variable mt_poor_app   "What medical treatment shall a SAM case will receive if he/she has illness or with poor appetite?"
label variable improve_nutri   "What are the steps taken by you for improving the nutritional status (i.e. SAM to Normal) of the SAM case?"
label variable nuri_msg   "Can you tell the key messages you give to the family of SAM case for enhancing the energy and nutrient of  daily diet?"
label variable sam_progress_fup   "How is SAM childs progress followed up during the programme period?"
label variable child_not_resp   "What you will do if the child does not gain weight or loses weight in two consecutive follow-ups visits"
label variable fup_activites   "What activities are being done during a follow-up session (VHSND or Home visit) of  child with SAM?"
label variable fup_duration   "Till what time a SAM child will be followed up and continued in programme?"
label variable what_done_aft_3mon   "What should be done if a child continues to remain in SAM category even after 3 months follow up period in CMAM program?"
label variable aww_skill_infanto   "Infantometer"
label variable aww_skill_salter   "Weighing -Salter weighing scale"
label variable aww_skill_stadio   "Stadiometer"
label variable aww_skill_dws   "Weighing -Digital weighing scale"
label variable aww_cal_wasting_cat   "AWW able to use ‘Weight for length/height z-score chart’, to classify the nutritional status (wasting) correctly?"
label variable child1_rw   "Child-1 Recorded weight **Poshan tracker** (Kgs)"
label variable child1_rhl   "Child-1 Recorded Height/Length **Poshan Tracker**  (cm)"
label variable child1_rcat   "Child-1 Wasting category **poshan tracker**"
label variable child1_cw   "Child-1 Current weight **as per Monitor** (Kgs)"
label variable child1_chl   "Child-1 Current Height/Length **as per Monitor** (cm)"
label variable child1_ccat   "Child-1 Wasting category **as per Monitor**"
label variable child2_rw   "Child-2 Recorded weight **Poshan tracker** (Kgs)"
label variable child2_rhl   "Child-2 Recorded Height/Length **Poshan Tracker**  (cm)"
label variable child2_rcat   "Child-2 Wasting category **poshan tracker**"
label variable child2_cw   "Child-2 Current weight **as per Monitor** (Kgs)"
label variable child2_chl   "Child-2 Current Height/Length **as per Monitor** (cm)"
label variable child2_ccat   "Child-2 Wasting category **as per Monitor**"
label variable c1_wt_diff   "c1_wt_diff"
label variable c2_wt_diff   "c2_wt_diff"
label variable c1_hl_diff   "c1_hl_diff"
label variable c2_hl_diff   "c2_hl_diff"
label variable child_aval_val   "Number of SAM child available for home visit currently"
label variable sam1_name   "Childs Name"
label variable sam1_mother   "Mothers name"
label variable sam1_sex   "Child Sex"
label variable sam1_age   "Age (completed months)"
label variable sam1_wt_measured_lm   "Was your child weight measured in last one month?"
label variable sam1_last_measured_date   "When was your childs weight last measured?"
label variable sam1_hl_measured_lm   "Was your child height/length measured in last one month?"
label variable sam1_aww_informed_sam   "Has AWW informed you about the childs current nutrition status?"
label variable sam1_child_medical_mgmt   "Has your child received any medical treatment in last one month at any health facility?"
label variable sam1_child_treat_con   "For what condition your child received the treatment?"
label variable sam1_child_mm_facility   "Where your child received medical treatment for malnutrition?"
label variable sam1_recd_med_vhsnd   "During treatment from VHSND/Sub-centre, has child received some medicines?"
label variable sam1_aww_visit   "Has AWW visited your home in last fifteen days to provide information on childs diet?"
label variable sam1_aww_msg   "Can you recall a few messages that AWW gave during the visit?"
label variable sam1_thr_recd   "Have you received THR in last one month for your child?"
label variable sam1_thr_recd_packets   "Number of THR packet received last month"
label variable sam1_coun_involve   "Who all were involved by AWW during the dietary counselling?"
label variable sam1_gm_mcp   "Growth Monitoring of child updated in MCP card"
label variable sam1_gm_pt   "Has AWW updated childs weight and height/length in poshan tracker?"
label variable sam1_meal_freq   "How many meals child consumed in last 24 hours (except snacks)"
label variable sam1_dh   "What mother/ caregiver fed child in last 24 hours"
label variable bm1   "bm1"
label variable cer1   "cer1"
label variable led1   "led1"
label variable ry_fruit_veg1   "ry_fruit_veg1"
label variable oth_veg1   "oth_veg1"
label variable dairy1   "dairy1"
label variable egg1   "egg1"
label variable meat1   "meat1"
label variable tot_dd_sam1   "tot_dd_sam1"
label variable sam1_en_enh_food   "Any food items used for enhancing energy and nutrient density of meals"
label variable sam1_en_enh_food_oth   "Specify other food items used for enhancing energy and nutrient density of meals"
label variable sam1_con_ifa   "Has your child consumed IFA syrup in last one week?"
label variable sam1_con_multivit   "Has your child consumed multivitamin in last day?"
label variable sam2_name   "Childs Name"
label variable sam2_mother   "Mothers name"
label variable sam2_sex   "Child Sex"
label variable sam2_age   "Age (completed months)"
label variable sam2_wt_measured_lm   "Was your child weight measured in last one month?"
label variable sam2_last_measured_date   "When was your childs weight last measured?"
label variable sam2_hl_measured_lm   "Was your child height/length measured in last one month?"
label variable sam2_aww_informed_sam   "Has AWW informed you about the childs current nutrition status?"
label variable sam2_child_medical_mgmt   "Has your child received any medical treatment in last one month at any health facility?"
label variable sam2_child_treat_con   "For what condition your child received the treatment?"
label variable sam2_child_mm_facility   "Where your child received medical treatment for malnutrition?"
label variable sam2_recd_med_vhsnd   "During treatment from VHSND/Sub-centre, has child received some medicines?"
label variable sam2_aww_visit   "Has AWW visited your home in last fifteen days to provide information on childs diet?"
label variable sam2_aww_msg   "Can you recall a few messages that AWW gave during the visit?"
label variable sam2_thr_recd   "Have you received THR in last one month for your child?"
label variable sam2_thr_recd_packets   "Number of THR packet received last month"
label variable sam2_coun_involve   "Who all were involved by AWW during the dietary counselling?"
label variable sam2_gm_mcp   "Growth Monitoring of child updated in MCP card"
label variable sam2_gm_pt   "Has AWW updated childs weight and height/length in poshan tracker?"
label variable sam2_meal_freq   "How many meals child consumed in last 24 hours (except snacks)"
label variable sam2_dh   "What mother/ caregiver fed child in last 24 hours"
label variable bm2   "bm2"
label variable cer2   "cer2"
label variable led2   "led2"
label variable ry_fruit_veg2   "ry_fruit_veg2"
label variable oth_veg2   "oth_veg2"
label variable dairy2   "dairy2"
label variable egg2   "egg2"
label variable meat2   "meat2"
label variable tot_dd_sam2   "tot_dd_sam2"
label variable sam2_en_enh_food   "Any food items used for enhancing energy and nutrient density of meals"
label variable sam2_en_enh_food_oth   "Specify other food items used for enhancing energy and nutrient density of meals"
label variable sam2_con_ifa   "Has your child consumed IFA syrup in last one week?"
label variable sam2_con_multivit   "Has your child consumed multivitamin in last day?"
label variable infant_sex   "Infant Sex"
label variable infant_del   "Infant Delivery Type"
label variable infant_bw   "Infant Birth Weight (in Kgs)"
label variable infant_bo   "Birth Order"
label variable infant_eibf   "When did you first breastfed your child ?"
label variable infant_ebf   "What did you give your baby in the last 24 hours?"
label variable feed_mode   "If child is on mixed or no breastfeeding, how are you feeding the child?"
label variable support_bf   "Has anyone counselled or supported you for promoting only breastfeeding?"
label variable infant_gm_records_pt   "Infants growth monitoring records available on Poshan Tracker"
label variable infant_gm_records_mcp   "Infants growth monitoring details updated on MCP card"
label variable infant_caregiver_aware_ns   "Caregivers aware about the nutrition status of the infant"
label variable infant_aww_visit   "How many times AWW visited infant in last one month"
label variable infant_asha_visit   "How many times ASHA visited infant in last one month"
label variable child_sex   "Child Sex"
label variable aww_hw_coun_diet_feed   "Has AWW visited your home in last one month to counsel the caregiver for diet and feeding?"
label variable aww_hw_coun_health_clean   "Has AWW visited your home in last one month to counsel the caregiver health, cleanliness and nutrition?"
label variable attended_ann   "Have you attended any annaprasan ceremony at the AWC in last three months?"
label variable child_wm_last_m   "Was your child weight measured in last one month?"
label variable child_hl_m   "Was your child height/length measured in last one month?"
label variable aww_informed_cns   "Has AWW informed you about the childs current nutrition status?"
label variable cf_started_68   "Has the child been introduced to Complementary Feeding"
label variable food_freq_68   "How many meals child consumed in last 24 hours (except snacks)"
label variable child_dh_child_68   "What mother/ caregiver fed child in last 24 hours"
label variable energy_food   "Any food items used for enhancing energy and nutrient density of meals"
label variable energy_food_oth   "Specify other food items used for enhancing energy and nutrient density of meals"
label variable child_sep_uten_68   "Does the child has separate utensils (like bowl, spoon, plate etc.)?"
label variable hus_invol_cf_68   "Who all involved in child’s feeding in any way?"
label variable child_68_cons_ifa   "Has your child consumed IFA syrup in last one week?"
label variable child_68_thr   "Have you received THR in last one month for your child?"

#delimit ;
label define TYPE_MON
     unicef_consultant "UNICEF"
     ngo_piramal "Piramal Swasthya"
     govt_health "Government - Health"
     govt_icds "Government - ICDS"
     coe_aiims "CoE - AIIMS Patna"
     other "Other"
;
label define JV
     yes "Yes"
     no "No"
;
label define DISTRICT
     gaya "Gaya"
     purnea "Purnea"
     araria "Araria"
;
label define BLOCK
     araria_sadar "Araria Sadar"
     bhargama_ "Bhargama"
;
label define FUNC_CHILD_WM
     fun "Functional"
     non_f "Non-Functional"
     na "Not Available"
;
label define FUNC_ADULT_WM
     fun "Functional"
     non_f "Non-Functional"
     na "Not Available"
;
label define FUNC_INFANTO
     fun "Functional"
     fun_a "Functional with adjustment"
     non_f "Non-Functional"
     na "Not Available"
;
label define FUNC_STADIO
     fun "Functional"
     fun_a "Functional with adjustment"
     non_f "Non-Functional"
     na "Not Available"
;
label define SAM_HANDOUT
     yes "Yes"
     no "No"
;
label define CMAM_MANUAL
     yes "Yes"
     no "No"
;
label define HCM_PREPARED
     yes "Yes"
     no "No"
     hcm_not_started "HCM not started"
;
label define SMART_M_PT
     yes "Yes"
     no "No"
;
label define SAM_DUE_LIST
     yes "Yes"
     no "No"
;
label define AWW_AWARE_MAL
     sam "SAM"
     mam "MAM"
     suw "SUW (Atikuposhit/ gambhir alpvazan)"
     uw "UW (Alpvazan)"
     dnk "dont know"
;
label define AWW_TRG_SAM
     yes "Yes"
     no "No"
;
label define AWW_AWARE_SAMBHAV
     yes "Yes"
     no "No"
;
label define AWW_SCREEN_SAM
     wt_hl "Weight and length/ height"
     l_h_age "length/ height and age"
     w_age "weight and age"
     dnk "Dont know"
;
label define AWW_AWARE_BL_PITTING
     aware "Aware"
     not_aware "Not aware"
;
label define SAM_FIRST_REF
     vhsnd "VHSND session for community management"
     nrc "NRC"
     chc_phc_rbsk "Nearest health facility (PHC/ CHC)/ RBSK"
     awc "Manage at AWC level only"
     dnk "dont know"
;
label define SAM_MT
     aware "Aware"
     not_aware "Not aware"
;
label define MT_POOR_APP
     aware "Aware"
     not_aware "Not aware"
;
label define CHILD_NOT_RESP
     vhsnd_session "VHSND session for community management"
     nrc "NRC"
     chc_phc_rbsk "Nearest health facility (PHC/ CHC)/ RBSK"
     dnk "dont know"
;
label define FUP_DURATION
     aware "Aware"
     not_aware "Not aware"
;
label define WHAT_DONE_AFT_3MON
     refer_nrc "Refer to NRC/Health Facility"
     continue_int_fup "Continue in the program with intensive follow-up"
     dnk "dont know"
;
label define AWW_CAL_WASTING_CAT
     yes "Yes"
     no "No"
;
label define CHILD1_RCAT
     sam "SAM"
     mam "MAM"
     normal "Normal"
;
label define CHILD1_CCAT
     sam "SAM"
     mam "MAM"
     normal "Normal"
;
label define CHILD2_RCAT
     sam "SAM"
     mam "MAM"
     normal "Normal"
;
label define CHILD2_CCAT
     sam "SAM"
     mam "MAM"
     normal "Normal"
;
label define SAM1_SEX
     male "Male"
     female "Female"
;
label define SAM1_WT_MEASURED_LM
     yes "Yes"
     no "No"
;
label define SAM1_HL_MEASURED_LM
     yes "Yes"
     no "No"
;
label define SAM1_AWW_INFORMED_SAM
     yes "Yes"
     no "No"
;
label define SAM1_CHILD_MEDICAL_MGMT
     yes "Yes"
     no "No"
;
label define SAM1_CHILD_TREAT_CON
     mm "Malnutrition management"
     other_ped "Any other paediatric illness - Diarrhoea, Fever, Cough etc."
;
label define SAM1_CHILD_MM_FACILITY
     vhnd "VHNSD"
     ss "Sub-centre"
     hwc "Health Wellness Centre"
     chc_phc "CHC/PHC"
     nrc "NRC"
;
label define SAM1_RECD_MED_VHSND
     yes "Yes"
     no "No"
;
label define SAM1_AWW_VISIT
     yes "Yes"
     no "No"
;
label define SAM1_THR_RECD
     yes "Yes"
     no "No"
;
label define SAM1_GM_MCP
     mcp_not_aval "MCP card not available"
     mcp_aval_gm_not_updated "MCP card available & Growth Monitoring not updated"
     mcp_aval_gm_updated "MCP card available & Growth Monitoring updated"
;
label define SAM1_GM_PT
     yes "Yes"
     no "No"
;
label define SAM1_MEAL_FREQ
     one "One"
     two "Two"
     three "Three or more"
     zero "No meal received"
;
label define SAM1_CON_IFA
     consumed "Consumed"
     not_con "Not consumed(bottle available)"
     bottle_not_aval "Bottle not available"
;
label define SAM1_CON_MULTIVIT
     yes "Yes"
     no "No"
     not_aval "Not available"
;
label define SAM2_SEX
     male "Male"
     female "Female"
;
label define SAM2_WT_MEASURED_LM
     yes "Yes"
     no "No"
;
label define SAM2_HL_MEASURED_LM
     yes "Yes"
     no "No"
;
label define SAM2_AWW_INFORMED_SAM
     yes "Yes"
     no "No"
;
label define SAM2_CHILD_MEDICAL_MGMT
     yes "Yes"
     no "No"
;
label define SAM2_CHILD_TREAT_CON
     mm "Malnutrition management"
     other_ped "Any other paediatric illness - Diarrhoea, Fever, Cough etc."
;
label define SAM2_CHILD_MM_FACILITY
     vhnd "VHNSD"
     ss "Sub-centre"
     hwc "Health Wellness Centre"
     chc_phc "CHC/PHC"
     nrc "NRC"
;
label define SAM2_RECD_MED_VHSND
     yes "Yes"
     no "No"
;
label define SAM2_AWW_VISIT
     yes "Yes"
     no "No"
;
label define SAM2_THR_RECD
     yes "Yes"
     no "No"
;
label define SAM2_GM_MCP
     mcp_not_aval "MCP card not available"
     mcp_aval_gm_not_updated "MCP card available & Growth Monitoring not updated"
     mcp_aval_gm_updated "MCP card available & Growth Monitoring updated"
;
label define SAM2_GM_PT
     yes "Yes"
     no "No"
;
label define SAM2_MEAL_FREQ
     one "One"
     two "Two"
     three "Three or more"
     zero "No meal received"
;
label define SAM2_CON_IFA
     consumed "Consumed"
     not_con "Not consumed(bottle available)"
     bottle_not_aval "Bottle not available"
;
label define SAM2_CON_MULTIVIT
     yes "Yes"
     no "No"
     not_aval "Not available"
;
label define INFANT_SEX
     male "Male"
     female "Female"
;
label define INFANT_DEL
     normal "Normal"
     c_sec "C-Section"
;
label define INFANT_BO
     1 "1"
     2 "2"
     3 "3"
     gr_3 "Greater than three"
;
label define INFANT_EIBF
     within_1 "Within 1 hour of Delivery"
     within1_3 "1-3 hour of Delivery"
     after_3 "After 3 hour of Delivery"
     next_day "next day of Delivery"
     cant_rem "Cant remember"
;
label define INFANT_EBF
     only_bm "Only Breastmilk"
     bm_fm "Breastmilk & Formula Milk"
     bm_am "Breastmilk & Animal Milk"
     bm_water "Breastmilk & water"
     fm "Formula Milk"
     am "Animal Milk"
     nothing "Nothing"
;
label define FEED_MODE
     bottle "Bottle"
     tumbler "Tumbler"
     katori_c "Katori-Chamach"
;
label define INFANT_GM_RECORDS_PT
     yes "Yes"
     no "No"
;
label define INFANT_GM_RECORDS_MCP
     yes "Yes"
     no "No"
;
label define INFANT_CAREGIVER_AWARE_NS
     yes "Yes"
     no "No"
;
label define CHILD_SEX
     male "Male"
     female "Female"
;
label define AWW_HW_COUN_DIET_FEED
     yes "Yes"
     no "No"
;
label define AWW_HW_COUN_HEALTH_CLEAN
     yes "Yes"
     no "No"
;
label define ATTENDED_ANN
     yes "Yes"
     no "No"
;
label define CHILD_WM_LAST_M
     yes "Yes"
     no "No"
;
label define CHILD_HL_M
     yes "Yes"
     no "No"
;
label define AWW_INFORMED_CNS
     yes "Yes"
     no "No"
;
label define CF_STARTED_68
     yes "Yes"
     no "No"
;
label define FOOD_FREQ_68
     one "One"
     two "Two"
     three "Three or more"
     zero "No meal received"
;
label define CHILD_SEP_UTEN_68
     yes "Yes"
     no "No"
;
label define CHILD_68_CONS_IFA
     consumed "Consumed"
     not_con "Not consumed(bottle available)"
     bottle_not_aval "Bottle not available"
;
label define CHILD_68_THR
     yes "Yes"
     no "No"
;

#delimit cr
label values type_mon     TYPE_MON
label values jv     JV
label values district     DISTRICT
label values block     BLOCK
label values func_child_wm     FUNC_CHILD_WM
label values Func_adult_wm     FUNC_ADULT_WM
label values func_infanto     FUNC_INFANTO
label values func_stadio     FUNC_STADIO
label values sam_handout     SAM_HANDOUT
label values CMAM_manual     CMAM_MANUAL
label values hcm_prepared     HCM_PREPARED
label values smart_m_pt     SMART_M_PT
label values sam_due_list     SAM_DUE_LIST
label values aww_aware_mal     AWW_AWARE_MAL
label values aww_trg_sam     AWW_TRG_SAM
label values aww_aware_sambhav     AWW_AWARE_SAMBHAV
label values aww_screen_sam     AWW_SCREEN_SAM
label values aww_aware_bl_pitting     AWW_AWARE_BL_PITTING
label values sam_first_ref     SAM_FIRST_REF
label values sam_mt     SAM_MT
label values mt_poor_app     MT_POOR_APP
label values child_not_resp     CHILD_NOT_RESP
label values fup_duration     FUP_DURATION
label values what_done_aft_3mon     WHAT_DONE_AFT_3MON
label values aww_cal_wasting_cat     AWW_CAL_WASTING_CAT
label values child1_rcat     CHILD1_RCAT
label values child1_ccat     CHILD1_CCAT
label values child2_rcat     CHILD2_RCAT
label values child2_ccat     CHILD2_CCAT
label values sam1_sex     SAM1_SEX
label values sam1_wt_measured_lm     SAM1_WT_MEASURED_LM
label values sam1_hl_measured_lm     SAM1_HL_MEASURED_LM
label values sam1_aww_informed_sam     SAM1_AWW_INFORMED_SAM
label values sam1_child_medical_mgmt     SAM1_CHILD_MEDICAL_MGMT
label values sam1_child_treat_con     SAM1_CHILD_TREAT_CON
label values sam1_child_mm_facility     SAM1_CHILD_MM_FACILITY
label values sam1_recd_med_vhsnd     SAM1_RECD_MED_VHSND
label values sam1_aww_visit     SAM1_AWW_VISIT
label values sam1_thr_recd     SAM1_THR_RECD
label values sam1_gm_mcp     SAM1_GM_MCP
label values sam1_gm_pt     SAM1_GM_PT
label values sam1_meal_freq     SAM1_MEAL_FREQ
label values sam1_con_ifa     SAM1_CON_IFA
label values sam1_con_multivit     SAM1_CON_MULTIVIT
label values sam2_sex     SAM2_SEX
label values sam2_wt_measured_lm     SAM2_WT_MEASURED_LM
label values sam2_hl_measured_lm     SAM2_HL_MEASURED_LM
label values sam2_aww_informed_sam     SAM2_AWW_INFORMED_SAM
label values sam2_child_medical_mgmt     SAM2_CHILD_MEDICAL_MGMT
label values sam2_child_treat_con     SAM2_CHILD_TREAT_CON
label values sam2_child_mm_facility     SAM2_CHILD_MM_FACILITY
label values sam2_recd_med_vhsnd     SAM2_RECD_MED_VHSND
label values sam2_aww_visit     SAM2_AWW_VISIT
label values sam2_thr_recd     SAM2_THR_RECD
label values sam2_gm_mcp     SAM2_GM_MCP
label values sam2_gm_pt     SAM2_GM_PT
label values sam2_meal_freq     SAM2_MEAL_FREQ
label values sam2_con_ifa     SAM2_CON_IFA
label values sam2_con_multivit     SAM2_CON_MULTIVIT
label values infant_sex     INFANT_SEX
label values infant_del     INFANT_DEL
label values infant_bo     INFANT_BO
label values infant_eibf     INFANT_EIBF
label values infant_ebf     INFANT_EBF
label values feed_mode     FEED_MODE
label values infant_gm_records_pt     INFANT_GM_RECORDS_PT
label values infant_gm_records_mcp     INFANT_GM_RECORDS_MCP
label values infant_caregiver_aware_ns     INFANT_CAREGIVER_AWARE_NS
label values child_sex     CHILD_SEX
label values aww_hw_coun_diet_feed     AWW_HW_COUN_DIET_FEED
label values aww_hw_coun_health_clean     AWW_HW_COUN_HEALTH_CLEAN
label values attended_ann     ATTENDED_ANN
label values child_wm_last_m     CHILD_WM_LAST_M
label values child_hl_m     CHILD_HL_M
label values aww_informed_cns     AWW_INFORMED_CNS
label values cf_started_68     CF_STARTED_68
label values food_freq_68     FOOD_FREQ_68
label values child_sep_uten_68     CHILD_SEP_UTEN_68
label values child_68_cons_ifa     CHILD_68_CONS_IFA
label values child_68_thr     CHILD_68_THR

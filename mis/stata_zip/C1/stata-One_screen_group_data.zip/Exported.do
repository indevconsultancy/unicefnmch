import delimited using "data.csv",delimiter(comma) varnames(1) case(preserve) asdouble encoding(UTF-8) clear

label variable uniqueid   "Unique Id"
label variable startDateTime   "Start DateTime"
label variable endDateTime   "End DateTime"
label variable device_id   "Device Id"
label variable GPS   "GPS"
label variable UserName   "UserName"
label variable SurveyStatus   "SurveyStatus"
label variable TerminationReason   "TerminationReason"
label variable today   "today"
label variable q1   "Monitor Name"
label variable q2   "Other Monitor Name"
label variable q3   "Select Monitor Type"
label variable q4   "Other Monitor Designation & organization"
label variable q5   "Date of Monitoring"
label variable q6   "district"
label variable q7   "block"
label variable q8   "other_block"
label variable q9   "village"
label variable q10   "Name"
label variable q11   "Age"
label variable q12   "Mobile number"

#delimit ;
label define Q1
     1 "Suresh Tiwari"
     2 "Ravi Prakash Srivastava"
     3 "Anurag Singh"
     4 "Praveen Dubey"
     5 "Other"
;
label define Q3
     1 "APC"
     2 "SPC"
     3 "Other"
;
label define Q6
     1 "Shravasti"
     2 "Gorakhpur"
;
label define Q7
     1 "Kaudiram"
     2 "JANGALKODIA"
;
label define Q10
     1 "Shravasti"
     2 "Gorakhpur"
;
label define Q11
     1 "Kaudiram"
     2 "JANGALKODIA"
;

#delimit cr
label values q1     Q1
label values q3     Q3
label values q6     Q6
label values q7     Q7
label values q10     Q10
label values q11     Q11
